#!/bin/bash
java -jar dist/AnotherGrep.jar $@
